SIMON FLOW FOR WINDOWS
======================
Talk, and Simon Flow types clean, grammatical text wherever your cursor is.

SET UP (one time)
1. Right-click the zip file > "Extract All..." and extract it somewhere you'll keep it,
   for example your Documents folder.
2. Open the extracted folder and double-click "Build and Open Simon Flow.bat".
   - If Windows says "Windows protected your PC", click "More info" and then "Run anyway".
   - A black window builds the app and, the first time, downloads the Whisper
     speech engine (about 150 MB, a few minutes). Then Simon Flow opens.
   - Already have an older Simon Flow? Just run this file again to upgrade.
   - A "Simon Flow" shortcut appears on your desktop. Use that from now on.
3. In Simon Flow's Settings, paste your Anthropic API key and click Save.
   (Get one at console.anthropic.com > API Keys. Using it costs a little money.)

USE IT
- Click into any text box (Word, Google Docs, a chat, anything).
- Press Ctrl + Alt + Space and talk.
- Press Ctrl + Alt + Space again. A moment later the cleaned-up text is typed in.
- A small bar at the bottom of the screen shows when it's listening.
- You can also click the big mic button in the app; the result is copied so you can paste it.

MORE THINGS IT CAN DO
- Styles: Natural, Concise, Formal, Email (formats a ready-to-send email) and Bullets.
- Hold to talk: hold your shortcut while you speak, let go to finish (Settings).
- Press Esc while recording to cancel. Nothing gets typed.
- Translate: talk in English and it types in Spanish, French, Japanese and more (Settings).
- Pick which microphone to use (Settings > Speech > Mic).
- See how fast you talk in words per minute, plus your average.
- Optional always-on pill at the bottom of the screen.

SETTINGS
- API key, keyboard shortcut, background color, sounds, and "start when Windows starts".
- Sounds: pick a start and a stop sound from Simon Flow's own sounds
  (Pop, Chime Up, Chime Down, Bubble, Blip, Soft Tap).
  The play button previews it.
- Closing the window keeps Simon Flow running (icon near the clock).
  Right-click that icon to quit.

IF THE MIC DOESN'T WORK
- Windows Settings > Privacy & security > Microphone:
  turn on "Microphone access" and "Let desktop apps access your microphone".
- Make sure the right microphone is the default one:
  Windows Settings > System > Sound > Input.
- Settings shows which speech engine is in use. It should say "Whisper".
  If it says "Windows built-in", run "Build and Open Simon Flow.bat" again
  while connected to the internet.
- If it says Whisper needs the "Visual C++ Redistributable", install it from
  aka.ms/vs/17/release/vc_redist.x64.exe and try again.

A log for troubleshooting is saved at:  %APPDATA%\SimonFlow\log.txt
